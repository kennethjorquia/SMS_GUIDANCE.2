<?php
    include('../../includes/functions.php');
    $id = $_GET['id'];
    
    $query = "DELETE FROM `guidance_post` WHERE `guidance_post`.`id` = '$id';";
        if(performQuery($query)){
            echo "<script>alert('Post has been deleted')</script>";
        }else{
            echo "Unknown error occured. Please try again.";
        }

?>
<br/><br/>
<a href="../../career_orientation.php">Back</a>