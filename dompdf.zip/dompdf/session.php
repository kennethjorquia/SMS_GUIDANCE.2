<?php
session_start();

include 'connection.php';

$name = $_POST['name'];
$age = $_POST['age'];

$_SESSION['name'] = $name;
$_SESSION['age'] = $age;


header("Location: pdf.php");