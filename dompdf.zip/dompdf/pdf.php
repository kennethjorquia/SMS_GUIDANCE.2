<?php
session_Start();

// inlucde auto loader
require_once 'dompdf/autoload.inc.php';


// Reference the Dompdf namespace
use Dompdf\Dompdf;

$pdf = new Dompdf();

// make the content here
// using output buffer

ob_start();
?>

<h1>Information</h1>
    Name: <label for="staticEmail" class="text-primary" id="staticEmail"><?php echo $_SESSION['name']; ?></label><br>
    Age: <label for="staticEmail" id="staticEmail"><?php echo $_SESSION['age']; ?></label>

<?php
$html=ob_get_clean();

$pdf->loadhtml($html);

//(Optional) Setup the paper size and orientation
//$pdf->setPaper('A4');

// Rendder the HTML or PDF
$pdf->render();

// Outout the generated PDF to Browser   (Always stream it)                       
$pdf->stream('result.pdf', Array('Attachment'=>0));

?>